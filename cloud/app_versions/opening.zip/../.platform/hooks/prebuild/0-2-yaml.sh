#! /bin/sh
sudo yum install -y libyaml-devel
