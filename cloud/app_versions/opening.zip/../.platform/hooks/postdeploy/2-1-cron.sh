#! /bin/sh
bin/whenever --load-file custom/config/schedule.rb --update-crontab
