module ApplicationCable
  # disable :reek:IrresponsibleModule
  class Channel < ActionCable::Channel::Base
  end
end
