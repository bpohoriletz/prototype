# disable :reek:IrresponsibleModule
# :nodoc:
module ApplicationHelper
end
