#! /bin/sh
bundle config set PATH /var/app/gems
