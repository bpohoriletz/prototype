# frozen_string_literal: true

module ApplicationCable
  # disable :reek:IrresponsibleModule
  class Channel < ActionCable::Channel::Base
  end
end
