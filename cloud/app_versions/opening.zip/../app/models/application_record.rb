class ApplicationRecord < ActiveRecord::Base # :nodoc:
  primary_abstract_class
end
