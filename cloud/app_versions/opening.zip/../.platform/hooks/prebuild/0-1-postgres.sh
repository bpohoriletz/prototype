#! /bin/sh
sudo yum install -y postgresql-devel
