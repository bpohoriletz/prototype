module ApplicationHelper # :nodoc:
end
