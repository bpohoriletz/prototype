# frozen_string_literal: true

module ApplicationCable
  # disable :reek:IrresponsibleModule
  class Connection < ActionCable::Connection::Base
  end
end
